# Season 7 Warzone Intelligence

Free static public dashboard for servers 294, 297, 304, 321, 325, 371, 383, 397. English, German, Italian, Spanish and French.

## Publish (no coding)
1. Create a free GitHub account.
2. Create a **public** repository called `season7-warzone-intel`.
3. Upload the CONTENTS of this ZIP, including the `data` folder and `.github/workflows/deploy.yml` (GitHub web upload may hide dot-folders on some devices; if so, upload `index.html`, `data` and `.nojekyll` and choose Pages -> Deploy from branch -> main/root instead).
4. In repository Settings -> Pages, choose **GitHub Actions** if the workflow was uploaded, otherwise **Deploy from a branch** (main/root).
5. The public URL will be `https://YOUR-USERNAME.github.io/season7-warzone-intel/`.

## Data and accuracy
The public data file is `data/snapshots.json`. Initially empty because no authorized full Top 200 THP export was verified. Replace with authorized records; all visitors then see the same dataset. No automatic scraping is enabled. No game credentials are requested.

Expected JSON: `{"schema_version":1,"source":"Authorized source name","snapshots":[{"snapshot_date":"2026-11-19","player_id":"unique-id","name":"Player","server":294,"alliance":"ABC","hero_power":123456789,"kills":12345,"rank":1}]}`. THP and kills must be raw integer values, not 'B' abbreviations. For Top 200 THP completeness, supply 200 distinct player IDs per server on one date. `kills:null` means unknown. If kill data only covers a separate top 100 kills ranking, DO NOT label it the Top 200 THP cohort kills.

Weekly activity compares matching player IDs between snapshots >=6 days apart, and does not claim to measure awake hours. This is an indicative metric, not exact 7-day matched-period measurement. The CSV import is only a local preview, not published to other visitors.

The historical bar chart is separately labeled as an earlier reported aggregate and is not used in Top 200 rankings.

## Known limitations
No verified machine-readable Top 200 feed or API authorization; therefore scheduled automatic ingestion is NOT implemented. The site is ready to host and to display verified imported data, not yet a live tracking service.
